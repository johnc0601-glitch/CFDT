'use client'

import {useEffect, useState} from 'react'
import type {ProjectMedia} from '@/types/projectMedia'

export function GraphicViewer({
  items,
  startIndex,
  onClose,
}: {
  items: ProjectMedia[]
  startIndex: number
  onClose: () => void
}) {
  const [index, setIndex] = useState(startIndex)
  const item = items[index]

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (event.key === 'Escape') onClose()
      if (event.key === 'ArrowRight') setIndex((value) => (value + 1) % items.length)
      if (event.key === 'ArrowLeft') setIndex((value) => (value - 1 + items.length) % items.length)
    }

    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [items.length, onClose])

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 p-4 text-white">
      <div className="mx-auto flex h-full max-w-7xl flex-col">
        <div className="flex items-center justify-between gap-4 py-2">
          <div>
            <p className="text-sm text-white/60">{index + 1} of {items.length}</p>
            <h2 className="text-xl font-semibold">{item.title}</h2>
          </div>
          <button onClick={onClose} className="rounded-full bg-white px-4 py-2 text-sm font-bold text-slate-900">Close</button>
        </div>

        <div className="relative flex-1 overflow-auto rounded-xl bg-white p-3">
          {item.imageUrl && <img src={item.imageUrl} alt={item.imageAlt || item.title} className="mx-auto h-auto max-w-none" />}
        </div>

        <div className="flex items-center justify-between gap-3 py-3">
          <button onClick={() => setIndex((value) => (value - 1 + items.length) % items.length)} className="rounded-xl bg-white/10 px-4 py-2 font-semibold">← Previous</button>
          <button onClick={() => setIndex((value) => (value + 1) % items.length)} className="rounded-xl bg-white/10 px-4 py-2 font-semibold">Next →</button>
        </div>
      </div>
    </div>
  )
}
