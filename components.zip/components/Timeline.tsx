import type {Project} from '@/types/project'

export function Timeline({timeline}: {timeline?: Project['timeline']}) {
  return (
    <section>
      <h2 className="text-2xl font-semibold">Project Timeline</h2>

      {!timeline || timeline.length === 0 ? (
        <p className="mt-4 text-slate-600">Timeline entries coming soon.</p>
      ) : (
        <div className="mt-6 space-y-5">
          {timeline.map((item, index) => (
            <div key={index} className="border-l-4 border-[#6f8b63] pl-5">
              <p className="text-sm font-bold uppercase tracking-widest text-[#6f8b63]">
                {item.stageStatus || 'Milestone'}
              </p>
              <h3 className="mt-1 text-xl font-semibold">{item.title}</h3>
              {item.date && <p className="mt-1 text-slate-500">{item.date}</p>}
              {item.description && <p className="mt-2 text-slate-600">{item.description}</p>}
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
