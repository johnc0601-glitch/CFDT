export type ProjectUpdate = {
  _id: string
  title: string
  date?: string
  summary?: string
  sourceUrl?: string
  projectName?: string
  projectSlug?: string
  isFeatured?: boolean
}
